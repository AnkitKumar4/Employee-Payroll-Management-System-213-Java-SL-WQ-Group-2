import { Salary } from './salary';

describe('Salary', () => {
  it('should create an instance', () => {
    expect(new Salary()).toBeTruthy();
  });
});
